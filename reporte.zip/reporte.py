# -*- coding: utf-8 -*-
import os
import subprocess
import json
import pandas as pd
import re
import sys
from datetime import datetime
import historico_enumeracion 



fecha_hora_actual = datetime.now()
hora = fecha_hora_actual.strftime("%H:%M:%S")
dia = fecha_hora_actual.strftime("%d")
mes = fecha_hora_actual.strftime("%m")
año = fecha_hora_actual.strftime("%Y")
# Verificar si se proporcionó la URL como argumento
if len(sys.argv) < 2:
    print("Uso: python reporte.py url")
    sys.exit(1)

# Obtener el dominio desde los argumentos de la línea de comandos
dominio = sys.argv[1]
dominio_sin_esquema = re.sub(r'https?://', '', dominio)

#tomamos todo hasta la primera / que aparezca
if '/' in dominio_sin_esquema:
    dominio_sin_esquema = dominio_sin_esquema.split('/')[0]

# Crear la carpeta 'resultado' si no existe
output_dir = 'resultado'
os.makedirs(output_dir, exist_ok=True)


# Crear la carpeta 'multimedia' si no existe (para almacenar las imágenes)
image_dir = 'multimedia'
os.makedirs(image_dir, exist_ok=True)

# Ruta del archivo txt basado en el dominio
ruta_archivo = os.path.join(output_dir, f'resultados_{dominio_sin_esquema}/resultados_{dominio_sin_esquema}.txt')

# Verificar si el archivo existe
if not os.path.exists(ruta_archivo):
    print(f"El archivo {ruta_archivo} no existe.")
    sys.exit(1)

# Leer el archivo completo
with open(ruta_archivo, 'r', encoding='utf-8') as archivo:
    contenido = archivo.read()



posibles_frases_inicio_cabceras = [
    'Análisis de cabeceras',
    'Analisis de cabeceras',  # Nota: Asegúrate de que esta frase esté correctamente escrita
    'Análisis de cabeceras HTTP'
]

# Inicializar variable para el índice de inicio
inicio_headers = None

# Buscar cada frase en el contenido
for frase in posibles_frases_inicio_cabceras:
    if frase in contenido:
        inicio_headers = contenido.index(frase)
        break  
# Definir los marcadores de posición para extraer las partes específicas
inicio_json = contenido.index('{')
fin_json = contenido.index('}\n\n') + 1
fin_headers = contenido.index('Fuzzing web')
inicio_waf = contenido.index('Escaneo de WAF')
# resultados_headers_resumen = contenido[fin_headers:inicio_waf].strip()

# Extraer y asignar las variables
respuestas_json = contenido[inicio_json:fin_json].strip()
respuestas_json = json.loads(respuestas_json)



respuesta_headers = contenido[inicio_headers:fin_headers].strip()
respuesta_waf = contenido[inicio_waf:].strip()



# virus_total = respuestas_json['virustotal']
# whois = respuestas_json['whois']
# ssl_status = respuestas_json['ssl_status']
# #sacamos el dominicio que viene en la primera linea de texto 

dominio = contenido.split('\n')[0]
dominio_sin_esquema = re.sub(r'https?://', '', dominio)

# #========================================parseo de whois========================================#
# #========================================parseo de whois========================================#
# #========================================parseo de whois========================================#

# # Verificar si el dominio es una dirección IP
# if re.match(r'^(\d{1,3}\.){3}\d{1,3}$', dominio_sin_esquema):
#     # Verificar que cada octeto esté en el rango 0-255
#     octetos = dominio_sin_esquema.split('.')
#     if all(0 <= int(octeto) <= 255 for octeto in octetos):
#         latex_whois = """
#         El análisis no se ejecutó debido a que la URL es una dirección IP.
#         """
#     else:
#         latex_whois = """
#         En este caso, el análisis del dominio no se efectuó de manera correcta debido a un formato incorrecto de la dirección IP.
#         """
# else:
#     # Procesar respuestas WHOIS
#     respuestas_whois = respuestas_json['whois']
#     # Validamos si las respuestas son None a cada llave del diccionario y las cambiamos por un string vacío
#     for key in respuestas_whois:
#         if respuestas_whois[key] is None:
#             respuestas_whois[key] = 'Nulo'

#     # Generar el contenido LaTeX
#     if respuestas_whois['domain_name'] != 'Nulo':
#         latex_whois = f"""
#         \\begin{{itemize}}
#         \\item Nombre del dominio: \\texttt{{"{respuestas_whois['domain_name']}" }}
#         \\item Registro: \\texttt{{"{respuestas_whois['registrar']}" }}
#         \\item Fecha de actualización: \\texttt{{"{respuestas_whois['updated_date']}"}}
#         \\item Fecha de creación del sitio: \\texttt{{"{respuestas_whois['creation_date']}" }}
#         \\item Fecha de expiración del sitio: \\texttt{{"{respuestas_whois['expiration_date']}" }}
#         \\item Servidores asociados: \\texttt{{"{(respuestas_whois['name_servers'])}" }}
#         \\item Email asociados a la renovación del sitio: \\url{{"{(respuestas_whois['emails'])}" }}
#         \\item Seguridad del DNS: \\texttt{{"{respuestas_whois['dnssec']}" }}
#         \\item Nombre: \\texttt{{{respuestas_whois['name']}}}
#         \\item Organización: \\texttt{{{respuestas_whois['org']} }}
#         \\item Ciudad: \\texttt{{{respuestas_whois['city']} }}
#         \\item Departamento: \\texttt{{{respuestas_whois['state']} }}
#         \\item País: \\texttt{{{respuestas_whois['country']} }}
#         \\end{{itemize}}
#         """
#     else:
#         latex_whois = """
#         En este caso, el análisis del dominio no se efectuó de manera correcta debido a que no se encontró información del dominio.

#         """



# #========================================parseo de antivirus========================================#
# #========================================parseo de antivirus========================================#
# #========================================parseo de antivirus========================================#
# #verificamos si malicious y suspicius es mayor que 
# # Verificamos si 'malicious' o 'suspicious' son mayores que 0
# #========================================parseo de antivirus========================================#
# #========================================parseo de antivirus========================================#
# #========================================parseo de antivirus========================================#
# #verificamos si malicious y suspicius es mayor que 
# # Verificamos si 'malicious' o 'suspicious' son mayores que 0
# if virus_total['stats']['malicious'] > 0 or virus_total['stats']['suspicious'] > 0:
#     # Verificamos si la clave 'detalles' existe en virus_total
#     if 'detalles' in virus_total:
#         # Extraer detalles de antivirus maliciosos y sospechosos si existen
#         malicious_details = virus_total['detalles'].get('malicious', {})
#         suspicious_details = virus_total['detalles'].get('suspicious', {})
        
#         lista = f"""
#         \\begin{{itemize}}
#             \\item Malicioso:  {{{{{virus_total['stats']['malicious']}}}}}
#             \\item Sospechoso: {{{{{virus_total['stats']['suspicious']}}}}}
#             \\item No Detectado:{{{{{virus_total['stats']['undetected']}}}}}
#             \\item Limpio:{{{{{virus_total['stats']['harmless']}}}}}
#         \\end{{itemize}}
#         La siguiente tabla ilustra de manera ordenada qué antivirus detectaron el archivo como malicioso o sospechoso, bajo qué criterio lo detectaron y el resultado obtenido:
#         """
        
#         # Construir contenido de la tabla en LaTeX
#         tabla_antivirus = """ 
#         \\begin{table}[h!]
#         \\centering
#         \\begin{tabular}{|l|l|l|l|}
#         \\hline
#         \\textbf{Antivirus} & \\textbf{Categoría} & \\textbf{Método} & \\textbf{Resultado} \\\\
#         \\hline
#         """

#         # Agregar detalles de antivirus maliciosos si existen
#         for antivirus, details in malicious_details.items():
#             tabla_antivirus += f"{antivirus} & {details['category']} & {details['method']} & {details['result']} \\\\ \\hline\n"

#         # Agregar detalles de antivirus sospechosos si existen
#         for antivirus, details in suspicious_details.items():
#             tabla_antivirus += f"{antivirus} & {details['category']} & {details['method']} & {details['result']} \\\\ \\hline\n"

#         # Cerrar la tabla
#         tabla_antivirus += """
#         \\end{tabular}
#         \\caption{Detalles de detección de antivirus}
#         \\end{table}
#         """
        
#         # Combinar la lista y la tabla
#         contenido_latex_antivirus = lista + tabla_antivirus

#     else:
#         # No hay detalles disponibles, generar solo la lista
#         contenido_latex_antivirus = f"""
#         \\begin{{itemize}}
#             \\item Malicioso:  {{{{{virus_total['stats']['malicious']}}}}}
#             \\item Sospechoso: {{{{{virus_total['stats']['suspicious']}}}}}
#             \\item No Detectado:{{{{{virus_total['stats']['undetected']}}}}}
#             \\item Limpio:{{{{{virus_total['stats']['harmless']}}}}}
#         \\end{{itemize}}
#         """
# else:
#     # No hay elementos maliciosos o sospechosos, generar solo la lista
#     contenido_latex_antivirus = f"""
#     \\begin{{itemize}}
#         \\item Malicioso:  {{{{{virus_total['stats']['malicious']}}}}}
#         \\item Sospechoso: {{{{{virus_total['stats']['suspicious']}}}}}
#         \\item No Detectado:{{{{{virus_total['stats']['undetected']}}}}}
#         \\item Limpio:{{{{{virus_total['stats']['harmless']}}}}}
#     \\end{{itemize}}
#     """





#========================================parseo de headers========================================#
#========================================parseo de headers========================================#
#========================================parseo de headers========================================#



#reemplazamos los saltos de linea por que sean \n por \\n y \n\n por \\n\\n
if '[3. Protocolos/Cabeceras de respuesta HTTP obsoletas o con valores inseguros]' in respuesta_headers:
    headers_content = respuesta_headers[respuesta_headers.index('[3. Protocolos/Cabeceras de respuesta HTTP obsoletas o con valores inseguros]'):respuesta_headers.index('[4.')]
    headers_content = headers_content.replace('\n', '\\\\\n').replace('\n\n', '\\\\\n\\\\\n')
    #reemplzamos los guiones bajos para evitar 
    headers_content = headers_content.replace('_', '\\_')


    # resultados_headers_resumen = resultados_headers_resumen.replace('\n', '\\\\\n').replace('\n\n', '\\\\\n\\\\\n')
    # #reemplzamos los guiones bajos para evitar 
    # resultados_headers_resumen = resultados_headers_resumen.replace('_', '\\_')

    #ponemos las siguientes frases que hay en el texto en negrita 
    headers_content = headers_content.replace(
        'Cabeceras de respuesta HTTP no habilitadas]',
        '\\begin{itemize}\\item \\textbf{Cabeceras de respuesta HTTP no habilitadas}\\end{itemize}'
    )
    headers_content = headers_content.replace(
        '[2. Huella digital por cabeceras de respuesta HTTP]',
        '\\begin{itemize}\\item \\textbf{Huella digital por cabeceras de respuesta HTTP}\\end{itemize}'
    )
    headers_content = headers_content.replace(
        '[3. Protocolos/Cabeceras de respuesta HTTP obsoletas o con valores inseguros]',
        '\\begin{itemize}\\item \\textbf{Protocolos/Cabeceras de respuesta HTTP obsoletas o con valores inseguros}\\end{itemize}'
    )
    headers_content = headers_content.replace(
        '[4. Cabeceras de respuesta HTTP sin valor]',
        '\\begin{itemize}\\item \\textbf{Cabeceras de respuesta HTTP sin valor}\\end{itemize}'
    )
    headers_content = headers_content.replace(
        '[5. Compatibilidad de navegadores para cabeceras de seguridad HTTP habilitadas]',
        '\\begin{itemize}\\item \\textbf{Compatibilidad de navegadores para cabeceras de seguridad HTTP habilitadas}\\end{itemize}'
    )
    headers_content = headers_content.replace('Ref:', '\\textbf{Ref:}\\')


    #cargamos la lsita de frases que vamos a reformatear
    df_frases = pd.read_csv('recursos\headers_formatted.csv')
    #iteramos sobre las frases y las reemplazamos por las frases en negrita
    for index, row in df_frases.iterrows():
        pattern = r'(?<![=/])' + re.escape(row['Header']) + r'(\\)'
        replacement = r'\\textbf{' + row['Header'] + r'}\\'
        headers_content = re.sub(pattern, replacement, headers_content)
else:
    headers_content = "No se encontró la sección de cabeceras en el análisis."       

##selecionamos que parte vamos a usar de headers content




###############################parseo de la respuesta de WAF#################3
###############################parseo de la respuesta de WAF#################3
###############################parseo de la respuesta de WAF#################3
###############################parseo de la respuesta de WAF#################3


pattern_waf = re.compile(r'\[FIREWALL\]\s*(.*?)\s*\(.*?\)', re.MULTILINE)

# Expresión regular para capturar las revalidaciones de WAF
pattern_revalidacion = re.compile(r'\[wf0\]\[\+\]\s*(The site .*? is behind .*? WAF\.)', re.MULTILINE)


# Intentar extraer los grupos usando ambas expresiones regulares
matches_waf = pattern_waf.findall(respuesta_waf)
matches_revalidacion = pattern_revalidacion.findall(respuesta_waf)

# Verificar si se encontraron coincidencias en la primera herramienta
if matches_waf:
    # Unir las coincidencias en un solo string para facilitar el procesamiento o almacenamiento
    parseo_waf = "\n".join(matches_waf)
else:
    parseo_waf = "No se identificó una protección de WAF en el dominio con la primera herramienta."

# Verificar si se encontraron coincidencias en la revalidación
if matches_revalidacion:
    # Unir las coincidencias en un solo string para facilitar el procesamiento o almacenamiento
    parseo_revalidacion = "\n".join(matches_revalidacion)
else:
    parseo_revalidacion = "No se identificó un WAF en la revalidación de WAF en el dominio."






imagen_vms = "multimedia/VMS.png"



##### tabla de parseo sobre le fuzzeo #####################################################3
#========================================parseo de fuzzeo========================================#
#========================================parseo de fuzzeo========================================#
#========================================parseo de fuzzeo========================================#

# Buscar la frase que marca el inicio del JSON
frase_inicio_fuzzing = "Fuzzing web\n\n"
pos_inicio_json_fuzzing = contenido.find(frase_inicio_fuzzing)

if pos_inicio_json_fuzzing != -1:
    # Ajustar la posición para iniciar justo después de la frase
    inicio_json_fuzzing = pos_inicio_json_fuzzing + len(frase_inicio_fuzzing)

    # Extraer la parte JSON del contenido
    json_string_fuzzing = contenido[inicio_json_fuzzing:]

    try:
        # Convertir la cadena JSON en un diccionario de Python
        data_fuzzing = json.loads(json_string_fuzzing)

        # Extraer la lista de responses
        responses_fuzzing = data_fuzzing.get('responses', [])

        # Crear la lista de tuplas con (path, status, content_length)
        resultados_fuzzing = [(response['path'], response['status'], response['content_length']) for response in responses_fuzzing]

        if resultados_fuzzing:
            # Definir el ancho de las columnas
            columna_path = '6cm'
            columna_status_code = '3cm'
            columna_content_length = '3cm'

            def escape_text(text):
                return text.replace('_', '\\textunderscore{}')

            # Construir el contenido de la tabla en LaTeX con anchos de columna especificados
            tabla_resultados_fuzzing = f"""
            \\begin{{longtable}}{{|p{{{columna_path}}}|p{{{columna_status_code}}}|p{{{columna_content_length}}}|}}
            \\hline
            \\textbf{{Path}} & \\textbf{{Status Code}} & \\textbf{{Content Length}} \\
            \\hline
            \\endfirsthead
            \\hline
            \\textbf{{Path}} & \\textbf{{Status Code}} & \\textbf{{Content Length}} \\
            \\hline
            \\endhead
            \\hline
            \\endfoot
            \\hline
            \\endlastfoot

            \\renewcommand{{\\arraystretch}}{{1.5}}  % Ajusta la altura de las filas
            """

            for path, status_code, content_length in resultados_fuzzing:
                # Escapar caracteres especiales en la columna "Path"
                path_text = escape_text(path)
                tabla_resultados_fuzzing += f"{path_text} & {status_code} & {content_length} \\\\ \\hline\n"

            tabla_resultados_fuzzing += """
            \\end{longtable}
            """
        else:
            # Mensaje en caso de que no haya resultados en la lista
            tabla_resultados_fuzzing = "El fuzzeo no se pudo realizar o no se encontraron resultados."

    except json.JSONDecodeError as e:
        tabla_resultados_fuzzing = f"Error al decodificar el JSON: {e}"
else:
    tabla_resultados_fuzzing = "No se encontró la frase de inicio del JSON Fuzzing."




############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################
############tabla de reporte de hallazgos #############################################

df_hallazgos = historico_enumeracion.procesar_datos(dominio)
columna_seccion = '2.5cm'
columna_condicional = '4.5cm'
columna_conclusion = '4cm'


def escape_text(text):
    return text.replace('_', '\\textunderscore{}')

# Crear la tabla con los anchos de columna especificados
tabla_hallazgos = f"""
\\begin{{longtable}}{{|p{{{columna_seccion}}}|p{{{columna_condicional}}}|p{{{columna_conclusion}}}|}}
\\hline
\\textbf{{Sección}} & \\textbf{{Condicional de Alertamiento}} & \\textbf{{Conclusión}} \\
\\hline
\\endfirsthead
\\hline
\\textbf{{Sección}} & \\textbf{{Condicional de Alertamiento}} & \\textbf{{Conclusión}} \\
\\hline
\\endhead
\\hline
\\endfoot
\\hline
\\endlastfoot

\\renewcommand{{\\arraystretch}}{{2}}  % Ajusta la altura de las filas
"""

for _, row in df_hallazgos.iterrows():
    # Escapar los caracteres especiales en la columna "Conclusión"
    conclusion_text = escape_text(row['conclusion'])
    codicional_text = escape_text(row['condicional_alertamiento'])
    seccion_text = escape_text(row['seccion'])
    tabla_hallazgos += f"{seccion_text} & {codicional_text} & {conclusion_text} \\\\ \\hline\n"

tabla_hallazgos += """
\\end{longtable}
"""

# Preparar contenido LaTeX con los valores extraídos
latex_content = f"""
\\documentclass{{article}}
\\usepackage{{fontspec}}
\\setmainfont{{Arial}}  
\\usepackage{{graphicx}}
\\usepackage{{color}}
\\usepackage{{xcolor}}
\\usepackage{{fancyhdr}}
\\usepackage{{geometry}}
\\usepackage[utf8]{{inputenc}}
\\usepackage[spanish]{{babel}}
\\usepackage{{url}}
\\usepackage{{eso-pic}}  % Paquete para colocar objetos en la página
\\usepackage{{adjustbox}}  % Paquete para ajustar el tamaño de la tabla
\\usepackage{{longtable}}  % Paquete para tablas largas

% Configuración de márgenes
\\geometry{{left=1in, right=1in, top=1in, bottom=2in}}
\\setlength{{\\parindent}}{{0pt}}

% Configuración de colores y títulos
\\usepackage{{titlesec}}
\\titleformat{{\\section}}{{\\bfseries\\Large}}{{\\thesection}}{{1em}}{{}}
\\titleformat{{\\subsection}}{{\\bfseries\\large}}{{\\thesubsection}}{{1em}}{{}}

% Configuración del encabezado y pie de página
\\setlength{{\\headheight}}{{100pt}} % Ajusta la altura del encabezado
\\fancypagestyle{{plain}}{{
    \\fancyhf{{}}
    \\renewcommand{{\\headrulewidth}}{{1.5pt}} % Elimina la línea superior predeterminada
    \\fancyhead[L]{{\\includegraphics[width=6.5cm]{{logo-grupo-bancolombia.png}}}}
    \\fancyfoot[C]{{\\rule{{\\textwidth}}{{0pt}}}} % Línea en el pie de página
}}

\\pagestyle{{fancy}}
\\fancyhf{{}}
\\renewcommand{{\\headrulewidth}}{{1.5pt}} % Elimina la línea superior predeterminada
\\fancyhead[L]{{\\includegraphics[width=6.5cm]{{logo-grupo-bancolombia.png}}}}
\\fancyfoot[C]{{\\rule{{\\textwidth}}{{0pt}}}} % Línea en el pie de página

% Pie de página con transparencia
\\AddToShipoutPictureBG{{
    \\AtTextLowerLeft{{
        \\put(0,-20){{\\textcolor{{gray}}{{\\Large Vulnerability And Exposure Management Service}}}}
    }}
}}

% Información del documento
\\title{{\\textbf{{Hallazgos Ciberinteligencia para el servicio URL}}}}
\\date{{}}

\\begin{{document}}
\\maketitle

% Fecha
\\textbf{{Fecha:}} {dia}/{mes}/{año}\\\\

% URL
\\textbf{{URL:}} {dominio}\\\\

% Gerencia 
\\textbf{{Gerencia:}} Gerencia de CiberInteligencia - Ciberseguridad Corporativa – 
GRUPO BANCOLOMBIA
\\vspace{{1cm}}

\\begin{{center}}
\\Large \\textbf{{VEMS (Vulnerability & Exposure Management Service)}}
\\end{{center}}
\\vspace{{0.5cm}}
% Imagen vms centrada 
\\begin{{center}}
\\includegraphics[width=15cm]{{{imagen_vms}}}
\\end{{center}}

\\vspace{{4cm}}

% Sección 1: Análisis de motores de antimalware
\\section{{Análisis de motores de antimalware}}

Esta herramienta analiza la URL junto con varios motores de antimalware que escanean patrones de comportamiento que son:


% Sección 4: Análisis de cabeceras
\\section{{Análisis de cabeceras}}

% respuesta headers
{headers_content}
\\vspace{{1em}}  % Añade un espacio vertical de 1 em
% Descripción de la tabla
\\noindent



% Sección 5: Escaneo de WAF
\\section{{Escaneo de WAF}}

% respuesta waf
\\textbf{{Resultados de nuestra primera herramienta:}} \\\\
\\small{{{parseo_waf}}}\\\\
\\textbf{{Resultados de la revalidación:}} \\\\
\\small{{{parseo_revalidacion}}}


% Hallazgos
\\section{{Hallazgos}}
{tabla_hallazgos}

% Fuzzing
\\section{{Fuzzing web}}
{tabla_resultados_fuzzing}



\\end{{document}}
"""





# Define la ruta del archivo .tex
tex_dir = os.path.dirname(ruta_archivo)  # Carpeta donde está el archivo .txt
tex_file = os.path.join(tex_dir, 'documento.tex')

# Guarda el contenido en el archivo .tex
with open(tex_file, 'w', encoding='utf-8') as f:
    f.write(latex_content)

# Define el nombre del archivo PDF
# Reemplaza las barras por guiones bajos
dominio_sin_esquema_limpio = dominio_sin_esquema.replace('/', '_')

pdf_filename = f'reporte_{dominio_sin_esquema_limpio}.pdf'
pdf_path = os.path.join(tex_dir, pdf_filename)

# Ruta de lualatex
lualatex_path = r"C:\Users\jcavenda\AppData\Local\Programs\MiKTeX\miktex\bin\x64\lualatex.exe"

# Ejecuta lualatex
subprocess.run([lualatex_path, '-interaction=nonstopmode', '-output-directory', tex_dir, '-jobname', f'reporte_{dominio_sin_esquema_limpio}', tex_file])


# Verifica si el archivo PDF se generó correctamente
if os.path.isfile(pdf_path):
    print(f'Archivo PDF generado correctamente: {pdf_path}')
else:
    print('Error al generar el archivo PDF.')