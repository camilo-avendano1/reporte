import os
import re
import json
import pandas as pd
from datetime import datetime
import sys

def procesar_datos(dominio):
    dominio_sin_esquema = re.sub(r'https?://', '', dominio)
    
    if '/' in dominio_sin_esquema:
        dominio_sin_esquema = dominio_sin_esquema.split('/')[0]

    output_dir = 'resultado'
    os.makedirs(output_dir, exist_ok=True)
    ruta_archivo = os.path.join(output_dir, f'resultados_{dominio_sin_esquema}/resultados_{dominio_sin_esquema}.txt')

    if not os.path.exists(ruta_archivo):
        print(f"El archivo {ruta_archivo} no existe.")
        return pd.DataFrame()

    with open(ruta_archivo, 'r', encoding='utf-8') as archivo:
        contenido = archivo.read()

    inicio_json = contenido.index('{')
    fin_json = contenido.index('}\n\n') + 1
    respuestas_json = json.loads(contenido[inicio_json:fin_json].strip())

    virus_total = respuestas_json.get('virustotal', {}).get('stats', {})
    whois = respuestas_json.get('whois', {})
    ssl_status = respuestas_json.get('ssl_status', {})







    columns = [
        'dominio',
        'dia',
        'mes',
        'año',
        'categoria',
        'seccion',
        'condicional_alertamiento',
        'url',
        'conclusion'
    ]

    df = pd.DataFrame(columns=columns)


    if virus_total.get('malicious') >= 1:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'Antimalware',
            'condicional_alertamiento': 'Malicioso >= 1',
            'url': dominio_sin_esquema,
            'conclusion': 'Se ha detectado en la URL un comportamiento malicioso por uno o más motores de antimalware'
        }
        
        # Agregar los datos al DataFrame
        df = df.append(data, ignore_index=True)



    if  virus_total.get('suspicious') >= 1:   
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'Antimalware',
            'condicional_alertamiento': 'Suspicious >= 1',
            'url': dominio_sin_esquema,
            'conclusion': 'Se ha detectado en la url un comportamiento sospechoso'
        }
        # Agregar los datos al DataFrame
    
    expiration_date_str = whois.get('expiration_date')

    # Verificar si `expiration_date` es una lista o un solo valor
    if isinstance(expiration_date_str, list):
        # Tomar el primer valor de la lista
        expiration_date_str = expiration_date_str[0]

    # Convertir el valor en un objeto `datetime`
    try:
        expiration_date = datetime.fromisoformat(expiration_date_str)
    except ValueError as e:
        print(f"Error al convertir la fecha: {e}")
        expiration_date = None


    if expiration_date < datetime.now():
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'Dominio',
            'condicional_alertamiento': 'Expiration_Date < fecha_actual',
            'url': dominio_sin_esquema,
            'conclusion': 'El dominio se encuentra expirado'
        }
        df = df.append(data, ignore_index=True)
    #miramos si el expiration date esta entre 90 o 120 dias a vencer

    if expiration_date < datetime.now() + pd.Timedelta(days=90) and expiration_date > datetime.now() + pd.Timedelta(days=120):
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'Dominio',
            'condicional_alertamiento': 'Expiration_Date < fecha_actual',
            'url': dominio_sin_esquema,
            'conclusion': 'El dominio se encuentra a punto de expirar'
        }
        df = df.append(data, ignore_index=True)

        #miramos is el iso code esta entre los paoses balcklist que estan en el archivo blacklist.txt

    with open("blacklist.txt", 'r', encoding='utf-8') as archivo:
        contenido = archivo.read().splitlines()  # Lee cada línea como un elemento en una lista

    # Verificar si el iso_code está en la lista negra
    iso_code = respuestas_json.get("geolocalizacion_ip", {}).get("iso_code", "")

    if iso_code in contenido:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'Geolocalización',
            'condicional_alertamiento': 'iso-code dentro de la blacklist paises bancolombial',
            'url': dominio_sin_esquema,
            'conclusion': 'La url pertenece a un pais el cual se encuentra como listas negras en bancolombia'
        }

    #verificamos si el ssl el cert_alg es diferente de los estandares SHA256
    if 'sha256' not in ssl_status.get('cert_alg', '').lower():
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'SSL',
            'condicional_alertamiento': f'Certificado SSL con algoritmo {ssl_status.get("cert_alg")} en lugar de SHA256',
            'url': dominio_sin_esquema,
            'conclusion': f'El certificado SSL usa un algoritmo ({ssl_status.get("cert_alg")}) que no es el estándar seguro SHA256'
        }
        df = df.append(data, ignore_index=True)

    #verificamos si ssl el issued_to es igual al dominio sin esquema
    if ssl_status.get('issued_to', '') != dominio_sin_esquema:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'SSL',
            'condicional_alertamiento': f'issued_to no coincide con la url',
            'url': dominio_sin_esquema,
            'conclusion': f'La firma del certificado no coincide que sea firmado para la url '
        }
        df = df.append(data, ignore_index=True)


    #verificamos el tiempo de expiracion del certificado ssl en valid_days_to_expire  es menor a 120
    if ssl_status.get('valid_days_to_expire', 0) < 120:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'SSL',
            'condicional_alertamiento': f'valid-days_to_expire < 120 dias',
            'url': dominio_sin_esquema,
            'conclusion': f'El certificado puede expirar en los 120 dias restantes'
        }
        df = df.append(data, ignore_index=True)   

    #verificamos el tamaño de la llave del vertificado es menor o igual a 1024
    if ssl_status.get('ssl_key_size', 0) <= 1024:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'API',
            'seccion': 'SSL',
            'condicional_alertamiento': f'ssl-key-size < 1024',
            'url': dominio_sin_esquema,
            'conclusion': f'El certificado puede ser sensible a ataques de fuerza bruta , algoritmo de cifrado debil'
        }
        df = df.append(data, ignore_index=True)


    #nmap
    puertos_habituales = {80, 443, 25}

    with open(ruta_archivo, 'r', encoding='utf-8') as archivo:
        contenido = archivo.read()

    # Extrae los puertos y protocolos del contenido
    pattern_nmap = r'\b\d{1,5}/(?:tcp|udp)\b'
    puertos = re.findall(pattern_nmap, contenido)

    # Convierte los puertos a un conjunto de números (sin el protocolo)
    puertos_extraidos = {int(p.split('/')[0]) for p in puertos}

    # Encuentra puertos no habituales
    puertos_no_habituales = puertos_extraidos - puertos_habituales

    # Si se encuentran puertos no habituales, agrega una fila al DataFrame
    for puerto in puertos_no_habituales:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'HACKING TOOL',
            'seccion': 'NMAP',
            'condicional_alertamiento': f'Discovered open port diferente a puertos habituales',
            'url': dominio_sin_esquema,
            'conclusion': f'Se ha detectado el puerto {puerto} expuesto'
        }
        df = df.append(data, ignore_index=True)
    #verificamos si esta esta frase tal cual en contenido [SUCCESS] no protection identified on target
    if '[SUCCESS] no protection identified on target' in contenido:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'HACKING TOOL',
            'seccion': 'WAF',
            'condicional_alertamiento': 'no protection identified on target',
            'url': dominio_sin_esquema,
            'conclusion': 'Se ha detectado que la url no posee proteccion WAF'
        }
        df = df.append(data, ignore_index=True)
    #verificamos si no estan ambas frases  [wf0] y [wwf] en contenido 
    if '[wf0]' not in contenido and '[wwf]' not in contenido:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'HACKING TOOL',
            'seccion': 'WAF',
            'condicional_alertamiento': 'No se ha identificado [wf0] y [wwf]',
            'url': dominio_sin_esquema,
            'conclusion': 'No se ha logrado escanear el WAF'
        }
        df = df.append(data, ignore_index=True)
    #verificamos si en fuzzeo responses esta vacio
    frase_inicio_fuzzing = "Fuzzing web\n\n"
    pos_inicio_json_fuzzing = contenido.find(frase_inicio_fuzzing)

    if pos_inicio_json_fuzzing != -1:
        # Ajustar la posición para iniciar justo después de la frase
        inicio_json_fuzzing = pos_inicio_json_fuzzing + len(frase_inicio_fuzzing)

        # Extraer la parte JSON del contenido
        json_string_fuzzing = contenido[inicio_json_fuzzing:]

        try:
            # Convertir la cadena JSON en un diccionario de Python
            data_fuzzing = json.loads(json_string_fuzzing)

            # Extraer la lista de responses
            responses_fuzzing = data_fuzzing.get('responses', [])

            # Verificar si la lista de responses está vacía
            if not responses_fuzzing:
                # Agregar una fila al DataFrame si la lista de responses está vacía
                data = {
                    'dominio': dominio_sin_esquema,
                    'dia': pd.Timestamp.now().day,
                    'mes': pd.Timestamp.now().month,
                    'año': pd.Timestamp.now().year,
                    'categoria': 'HACKING TOOL',
                    'seccion': 'FUZZING WEB',
                    'condicional_alertamiento': '"responses": []',
                    'url': dominio_sin_esquema,
                    'conclusion': 'El fuzzing web no ha detectado rutas ocultas'
                }
                df = df.append(data, ignore_index=True)

        except json.JSONDecodeError as e:
            print(f"Error al decodificar el JSON: {e}")
    else:
        print("No se encontró la frase de inicio del JSON Fuzzing.")

    ##verificamos si esta el siguiente error al fuzzear
    if 'ERROR: Could not connect to any target provided' in contenido:
        data = {
            'dominio': dominio_sin_esquema,
            'dia': pd.Timestamp.now().day,
            'mes': pd.Timestamp.now().month,
            'año': pd.Timestamp.now().year,
            'categoria': 'HACKING TOOL',
            'seccion': 'WAF',
            'condicional_alertamiento': '[ERROR: Could not connect to any target provided]',
            'url': dominio_sin_esquema,
            'conclusion': 'El fuzzing web no se ha podido ejecutar debido a problemas con la url'
        }
        df = df.append(data, ignore_index=True)

    ##datos del fuzzeo 


    # Buscar la sección de JSON de fuzzing
    frase_inicio_fuzzing = "Fuzzing web\n\n"
    pos_inicio_json_fuzzing = contenido.find(frase_inicio_fuzzing)

    if pos_inicio_json_fuzzing != -1:
        # Ajustar la posición para iniciar justo después de la frase
        inicio_json_fuzzing = pos_inicio_json_fuzzing + len(frase_inicio_fuzzing)

        # Extraer la parte JSON del contenido
        json_string_fuzzing = contenido[inicio_json_fuzzing:]

        try:
            # Convertir la cadena JSON en un diccionario de Python
            data_fuzzing = json.loads(json_string_fuzzing)

            # Extraer la lista de responses
            responses_fuzzing = data_fuzzing.get('responses', [])

            # Crear la lista de tuplas con (path, status, content_length)
            resultados_fuzzing = [(response['path'], response['status'], response['content_length']) for response in responses_fuzzing]

            # Crear una lista para almacenar los datos
            data_list = []

            for path, status, content_length in resultados_fuzzing:
                data = {
                    'dominio': dominio_sin_esquema,
                    'dia': pd.Timestamp.now().day,
                    'mes': pd.Timestamp.now().month,
                    'año': pd.Timestamp.now().year,
                    'categoria': 'HACKING TOOL',
                    'seccion': 'FUZZING WEB',
                    'condicional_alertamiento': f'"statuscode":"{status}"',
                    'url': dominio_sin_esquema,
                    'conclusion': path
                }
                data_list.append(data)

            # Convertir la lista en un DataFrame
            df_fuzzing = pd.DataFrame(data_list)

            # Concatenar el DataFrame original con el nuevo DataFrame
            df = pd.concat([df, df_fuzzing], ignore_index=True)

        except json.JSONDecodeError as e:
            print(f"Error al decodificar el JSON: {e}")
    else:
        print("No se encontró la frase de inicio del JSON Fuzzing.")

    # Nombre del archivo CSV
    archivo_csv = 'historico_enumeracion.csv'

    # Verifica si el archivo ya existe
    file_exists = os.path.isfile(archivo_csv)

    # Guarda el DataFrame en el archivo CSV en modo append
    df.to_csv(archivo_csv, mode='a', index=False, header=not file_exists)
    
    
    return df

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Uso: python script.py <dominio>")
        sys.exit(1)

    dominio = sys.argv[1]
    df = procesar_datos(dominio)
    if not df.empty:
        print(df)
